
mod argc;

pub mod main_basanta{
    pub fn demo() {
        println!("Hello, world!");
        crate::argc::test_fun();
        println!("from v 0.1.3");
    }
}