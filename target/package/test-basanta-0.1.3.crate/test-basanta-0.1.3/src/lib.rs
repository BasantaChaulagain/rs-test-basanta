
mod argc;

pub mod main_basanta{
    pub fn demo() {
        println!("Hello, world!");
        crate::argc::test_fun();
    }
}